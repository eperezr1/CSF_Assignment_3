Team members:
Amy Lin
Emily Perez-Rodriguez

Contributions:
Given the less structured nature of this assignment, we took a collaborative approach to completing it.
Emily did the Makefile and we both updated it as needed. Amy did the Block and Set classes. Emily started the Cache
class load and store methods as well as the logic for evicting a block, and Amy helped implement helper methods, add in the lru timestamp logic, and fixed bugs in the load and store methods. Emily wrote code to test that the parameters were
valid in main.cpp, Amy implemented the logic to get the tag and set_index , and we both worked on the file parsing.
